import MuiForm from './components/Form';
import './App.css'

function App() {

  return (
    <>
      <MuiForm />;
    </>
  )
}

export default App
