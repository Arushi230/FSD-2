import './Dashboard.css';

export default function Dashboard() {
  return (
    <div className="dashboard">
      <div className="dashboard-card">
        <h2>Dashboard Component</h2>
        <p>This component is loaded lazily.</p>
      </div>
    </div>
  );
}
